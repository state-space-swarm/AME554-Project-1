function task3_554project
%SO(3) regulation control

% A matrix
A = [5, 0, 0; 0, 6, 0; 0, 0, 9];
% 
% % Control law 
% sA = 1/2*Vee((A*R-R'*A));
% wc = -k*sA;

% Set up the time vector
t0 = 0;
tf = 60; % One minute simulation
dt = .1;  % 0.1-second intervals
t = [t0:dt:tf]; % Time

% gain
K = 0.05;


psi_0  = 100*pi/180; 
theta_0 = 60*pi/180;
phi_0  = 30*pi/180;

% Initial rotation about each axis  
R1 = [cos(psi_0) sin(psi_0) 0;
    -sin(psi_0) cos(psi_0) 0;
      0         0          1];

R2 = [1   0            0;
      0 cos(theta_0)  sin(theta_0);
      0 -sin(theta_0) cos(theta_0)];

R3 = [cos(phi_0) sin(phi_0) 0;
     -sin(phi_0) cos(phi_0) 0;
      0          0          1];

R0 = R3*R2*R1; % Initial rotation matrix

R = zeros(3,3,length(t)); % Rotation matrix for all time steps
R(:,:,1) = R0;

R11(1) = R(1,1,1);  % Elements of the initial rotation matrix
R12(1) = R(1,2,1);
R13(1) = R(1,3,1);
R21(1) = R(2,1,1);
R22(1) = R(2,2,1);
R23(1) = R(2,3,1);
R31(1) = R(3,1,1);
R32(1) = R(3,2,1);
R33(1) = R(3,3,1);





for k = 1: length(t)-1
     sA = 1/2*Vee((A*R(:,:,k)-R(:,:,k).'*A));
   wc = -K*sA;
   w_cross = skew(wc);
    R(:,:,k+1) = R(:,:,k) * expm(dt * w_cross); % Integration
end

for k =2:length(t)      % Elements of the rotation matrix at each time step 
    R11(k) = R(1,1,k);
    R12(k) = R(1,2,k);
    R13(k) = R(1,3,k);
    R21(k) = R(2,1,k);
    R22(k) = R(2,2,k);
    R23(k) = R(2,3,k);
    R31(k) = R(3,1,k);
    R32(k) = R(3,2,k);
    R33(k) = R(3,3,k);
    err(k) = norm(eye(3)-R(:,:,k)*R(:,:,k)','fro');
end

for k=1:length(t)
    PRA(k) = acos((trace(R(:,:,k))-1)/2);
    cont(:,k) = -k*1/2*Vee((A*R(:,:,k)-R(:,:,k).'*A));
    contnorm(k)=norm(cont(:,k));
end



% Plot
figure(1)
subplot(1,3,1)
plot(t, R11, 'Linewidth', 1.5); hold on
plot(t, R12, 'Linewidth', 1.5);  hold on
plot(t, R13, 'Linewidth', 1.5);  hold on
plot(t, R21, 'Linewidth', 1.5); hold on
plot(t, R22, 'Linewidth', 1.5); hold on
plot(t, R23, 'Linewidth', 1.5);  hold on
plot(t, R31, 'Linewidth', 1.5);  hold on
plot(t, R32, 'Linewidth', 1.5);  hold on
plot(t, R33, 'Linewidth', 1.5);

xlabelentries = {'$$t$$ (s)'};
xlabel(xlabelentries, 'interpreter', 'latex', 'FontName', 'Times', 'fontsize', 14)
ylabelentries = {'Components of R'};
ylabel(ylabelentries, 'interpreter', 'latex', 'FontName', 'Times', 'fontsize', 14)
grid on;
legend('R11','R12','R13','R21','R22','R23','R31','R32','R33','Location','northeast')
title('Nine Components of R')

subplot(1,3,2)
hold on
plot(t, cont(1,:))
plot(t, cont(2,:))
plot(t, cont(3,:))
plot(t, contnorm,'c','LineWidth',1.5, 'LineStyle','--')
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
grid on
xlabelentries = {'$$t$$ (s)'};
xlabel(xlabelentries, 'interpreter', 'latex', 'FontName', 'Times', 'fontsize', 14)
ylabel('\omega [rad/s]')
xlim([0 tf])
title('Angular Velocity')

subplot(1,3,3)
plot(t, PRA,'r','LineWidth',2)
grid on
xlabelentries = {'$$t$$ (s)'};
xlabel(xlabelentries, 'interpreter', 'latex', 'FontName', 'Times', 'fontsize', 14)
ylabelentries = {'Principle Angle (rads)'};
ylabel(ylabelentries, 'interpreter', 'latex', 'FontName', 'Times', 'fontsize', 14)
title('PRA vs Time')



figure(2)
plot(t, err)
grid on
xlabel('t(s)')
ylabel('orthogonality error')







% Morse-Lyapunov Function
theta = linspace(0, pi, 100);       % Rotation angle
phi = linspace(0, 2*pi, 100);       % Axis angle 

[Theta, Phi] = meshgrid(theta, phi);

e1 = cos(Phi);
e2 = sin(Phi);
e3 = zeros(size(Phi));  
norms = sqrt(e1.^2 + e2.^2 + e3.^2);
e1 = e1 ./ norms;
e2 = e2 ./ norms;

V = zeros(size(Theta));

for i = 1:numel(Theta)

    e = [e1(i); e2(i); 0];
    
    e_cross = [  0   -e(3)  e(2);
                e(3)   0   -e(1);
               -e(2)  e(1)   0 ];
    
    th = Theta(i);
    
    R = eye(3) + sin(th)*e_cross + (1 - cos(th))*(e_cross^2);
    
    
    V(i) = 0.5 * trace(A - A*R);
end


figure;
mesh(Theta, Phi, V);
xlabel('\theta (rad)');
ylabel('\phi (rad)');
zlabel('V(R)');
title('Morse-Lyapunov Function V(R)');
colormap turbo;
shading interp;



end

function [X] = Vee(A)
%unskews matrix
a1 = A(3,2);
a2 = A(1,3);
a3 = A(2,1);

X = [a1; a2; a3];
end

function [X] = skew(A)
% This function takes a 3x1 matrix and returns the skew symmetric
% corresponding matrix

[rows, colms] = size(A);
if rows == 3
    elseif rows > 3 | rows < 3
    stop "Cannot compute skew matrix, dimensions are not valid of input matrix"
end


if colms == 1
    elseif colms > 1
    stop "Cannot compute skew matrix, dimensions are not valid of input matrix"
end

a1 = A(1);
a2 = A(2);
a3 = A(3);

X = [0, -a3, a2; a3, 0, -a1; -a2, a1, 0];

end