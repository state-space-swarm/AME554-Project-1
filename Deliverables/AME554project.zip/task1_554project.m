function task1_554project
% This code performs attitude regulation using PRV, Quats, and MRPs
% Time vector
t0 = 0;
dt = 0.01;
tf = 45;
time = [t0:dt:tf];


% Attitude Regulation control using PRV, Quats, and MRPS
%% PRV
k = .45; % gain

ehat1 = -0.3626;
ehat2 = 0.3725;
ehat3 = 0.8543;
phi = 268 * pi/180;
IC = [phi*ehat1, phi*ehat2, phi*ehat3]';

% Tolerance
tolerance = 1e-6;

% Setting up ODE45
options = odeset('RelTol',tolerance,'AbsTol',tolerance);

% Integrating with a simple 2-body integrator
[t, X] = ode45(@PRV, time, IC, options);

prvcont = -k * X;

prv_cost = trapz(t, sum(prvcont.^2, 2))


for i = 1:length(time)
    PRA(i) = norm(X(i),2);
    omega(i) = norm(prvcont(i,:));
end

figure;
subplot(1,3,1)
hold on
plot(time, X(:,1), 'r', 'LineWidth',1.5)
plot(time, X(:,2), 'b', 'LineWidth',1.5)
plot(time, X(:,3), 'g', 'LineWidth',1.5)
legend('PRV_1','PRV_2','PRV_3','Location','northeast')
xlim([0 tf])
grid on
xlabel('time [sec]')
ylabel('PRV Components')
title('PRV')
subplot(1,3,2)
hold on
grid on
plot(time, prvcont)
plot(time, omega, 'c','LineStyle','--','LineWidth',1.5)
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
xlabel('time [sec]')
ylabel('\omega')
title('Angular Velocity')
xlim([0 tf])
grid on
subplot(1,3,3)
plot(time, PRA, 'r', 'LineWidth',1.5)
grid on
xlabel('time [sec]')
ylabel('Principle Angle')
title('Principle Angle')
xlim([0 tf])


% Proving globally asympt stable for PRV control
% Lyapunov function
g1_range = linspace(-50, 50, 500);
g2_range = linspace(-50, 50, 500);

[G1, G2] = meshgrid(g1_range, g2_range);

G3 = sqrt(max(0, 1 - G1.^2 - G2.^2));

% Lyapunov function V = gamma' * gamma
V = G1.^2 + G2.^2 + G3.^2; 

% Plot the Lyapunov function
figure;
surf(G1, G2, V);
colormap turbo;
shading interp; 
xlabel('\gamma_1');
ylabel('\gamma_2');
zlabel('V');
title('Lyapunov Function for PRV Control');
grid on;


% Range of IC
phi = [90:30:270]*pi/180;
for j=1:length(phi)
    IC = [phi(j)*ehat1, phi(j)*ehat2, phi(j)*ehat3]';
    [t, X] = ode45(@PRV, time, IC, options);
    for i=1:length(time)
    PRAV(i,j) = norm(X(i),2) * 180/pi;
    end
end

figure;
hold on
for j=1:length(phi)
    plot(time, PRAV(:,j))
end
grid on
ylim([0 180])
xlim([0 tf])
ylabel('Principle Axis [deg]')
title('Linear PRV Control (Range of IC)')
xlabel('Time [sec]')
legend('90','120','150','180','210','240','270')

%% Quats

% Linear control 
phi = 268 * pi/180;
q1 = ehat1*sin(phi/2); q2 = ehat2*sin(phi/2); q3 = ehat3*sin(phi/2); 
q4 = cos(phi/2);
ICs = [q1, q2, q3, q4];

% [t1, X1] = ode45(@quat1, time, IC, options);

dt2 = dt/2; dt6 = dt/6;       

% 
mag = zeros(length(time),1);
quat = zeros(length(time),4);
quatn = zeros(length(time),4);
mag(1) = norm(ICs);
quat(1,:) = ICs;
quatn(1,:) = ICs/mag(1);

for nk = 1:2
   if nk==1 
      x0=quat(1,:)';
   else
      x0=quatn(1,:)';
   end
   for i=2:length(time)
      t = time(i-1);
      tt = t + dt2;
      dxdt = deriv_quat(t,x0);
      x0t = x0 + dt2*dxdt;
      dx0t = deriv_quat(tt,x0t);
      x0t = x0 + dt2*dx0t;
      dxmold = deriv_quat(tt,x0t);
      x0t = x0 + dt*dxmold;
      dxm = dx0t + dxmold;
      dx0t = deriv_quat(t + dt, x0t);
      x0 = x0 + dt6*(dxdt + dx0t + 2*dxm);
      if nk==1 
        quat(i,:) = x0';
        mag(i) = norm(x0);
      else
        quatn(i,:) = x0/norm(x0);
      end
   end
end

quat1cont = -k * quatn(:,1:3);
quat1_cost = trapz(t, sum(quat1cont.^2, 2))

% Principle angle error
for j = 1:length(time)
PRA(j) = mod(2*atan2(norm(quatn(j,1:3),2),quatn(j,4)) * 180/pi,180);
omega(j) = norm(quat1cont(j,:));
end

figure;
subplot(1,3,1)
hold on
plot(time, quatn(:,1), 'r', 'LineWidth',1.5)
plot(time, quatn(:,2), 'b', 'LineWidth',1.5)
plot(time, quatn(:,3), 'g', 'LineWidth',1.5)
plot(time, quatn(:,4), 'c', 'LineWidth',1.5)
legend('q_1','q_2','q_3','q_4','location','northeast')
title('Linear Quat Feedback')
grid on
xlabel('time [sec]')
ylabel('Quat Components')
xlim([0 tf])
subplot(1,3,2)
hold on
plot(time, quat1cont)
plot(time, omega, 'c','LineStyle','--','LineWidth',1.5)
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
title('Angular Velocity')
grid on
xlabel('time [sec]')
ylabel('\omega [rad/s]')
xlim([0 tf])
subplot(1,3,3)
plot(time, PRA, 'r', 'LineWidth',1.5)
grid on
title('Principle Angle Error')
xlabel('time [sec]')
ylabel('PRA [deg]')
xlim([0 tf])
ylim([0 180])

%% Discontinuous control Quats


mag = zeros(length(time),1);
quat = zeros(length(time),4);
quatn = zeros(length(time),4);
mag(1) = norm(ICs);
quat(1,:) = ICs;
quatn(1,:) = ICs/mag(1);

for nk = 1:2
   if nk==1 
      x0=quat(1,:)';
   else
      x0=quatn(1,:)';
   end
   for i=2:length(time)
      t = time(i-1);
      tt = t + dt2;
      dxdt = deriv_quat1(t,x0);
      x0t = x0 + dt2*dxdt;
      dx0t = deriv_quat1(tt,x0t);
      x0t = x0 + dt2*dx0t;
      dxmold = deriv_quat1(tt,x0t);
      x0t = x0 + dt*dxmold;
      dxm = dx0t + dxmold;
      dx0t = deriv_quat1(t + dt, x0t);
      x0 = x0 + dt6*(dxdt + dx0t + 2*dxm);
      if nk==1 
        quat(i,:) = x0';
        mag(i) = norm(x0);
      else
        quatn(i,:) = x0/norm(x0);
      end
   end
end

quat2cont = -k *sign(quatn(4)) * quatn(:,1:3);
quat2_cost = trapz(t, sum(quat2cont.^2, 2))

% Principle angle error
for j = 1:length(time)
PRA(j) = mod(2*atan2(norm(quatn(j,1:3),2),abs(quatn(j,4))) * 180/pi,180);
omega(j) = norm(quat2cont(j,:));
end

figure;
subplot(1,3,1)
hold on
plot(time, quatn(:,1), 'r', 'LineWidth',1.5)
plot(time, quatn(:,2), 'b', 'LineWidth',1.5)
plot(time, quatn(:,3), 'g', 'LineWidth',1.5)
plot(time, quatn(:,4), 'c', 'LineWidth',1.5)
legend('q_1','q_2','q_3','q_4','location','northeast')
title('Discontinuous Quat Feedback')
grid on
xlabel('time [sec]')
ylabel('Quat Components')
xlim([0 tf])
subplot(1,3,2)
hold on
plot(time, quat2cont)
plot(time, omega, 'c','LineStyle','--','LineWidth',1.5)
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
title('Angular Velocity')
grid on
xlabel('time [sec]')
ylabel('\omega [rad/s]')
xlim([0 tf])
subplot(1,3,3)
plot(time, PRA, 'r', 'LineWidth',1.5)
grid on
title('Principle Angle Error')
xlabel('time [sec]')
ylabel('PRA [deg]')
xlim([0 tf])
ylim([0 180])


%% Non Linear Control Quats
mag = zeros(length(time),1);
quat = zeros(length(time),4);
quatn = zeros(length(time),4);
mag(1) = norm(ICs);
quat(1,:) = ICs;
quatn(1,:) = ICs/mag(1);

for nk = 1:2
   if nk==1 
      x0=quat(1,:)';
   else
      x0=quatn(1,:)';
   end
   for i=2:length(time)
      t = time(i-1);
      tt = t + dt2;
      dxdt = deriv_quat2(t,x0);
      x0t = x0 + dt2*dxdt;
      dx0t = deriv_quat2(tt,x0t);
      x0t = x0 + dt2*dx0t;
      dxmold = deriv_quat2(tt,x0t);
      x0t = x0 + dt*dxmold;
      dxm = dx0t + dxmold;
      dx0t = deriv_quat2(t + dt, x0t);
      x0 = x0 + dt6*(dxdt + dx0t + 2*dxm);
      if nk==1 
        quat(i,:) = x0';
        mag(i) = norm(x0);
      else
        quatn(i,:) = x0/norm(x0);
      end
   end
end


quat3cont = -k * quatn(4) * quatn(:,1:3);
quat3_cost = trapz(t, sum(quat3cont.^2, 2))

% Principle angle error
for j = 1:length(time)
PRA(j) = mod(2*atan2(norm(quatn(j,1:3),2),abs(quatn(j,4))) * 180/pi,180);
omega(j) = norm(quat3cont(j,:));
end

figure;
subplot(1,3,1)
hold on
plot(time, quatn(:,1), 'r', 'LineWidth',1.5)
plot(time, quatn(:,2), 'b', 'LineWidth',1.5)
plot(time, quatn(:,3), 'g', 'LineWidth',1.5)
plot(time, quatn(:,4), 'c', 'LineWidth',1.5)
legend('q_1','q_2','q_3','q_4','location','northeast')
title('Nonlinear Quat Feedback')
grid on
xlabel('time [sec]')
ylabel('Quat Components')
xlim([0 tf])
subplot(1,3,2)
hold on
plot(time, quat3cont)
plot(time, omega, 'c','LineStyle','--','LineWidth',1.5)
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
title('Angular Velocity')
grid on
xlabel('time [sec]')
ylabel('\omega [rad/s]')
xlim([0 tf])
subplot(1,3,3)
plot(time, PRA, 'r', 'LineWidth',1.5)
grid on
title('Principle Angle Error')
xlabel('time [sec]')
ylabel('PRA [deg]')
xlim([0 tf])
ylim([0 180])

% Range of IC 
ehat1 = -0.3626;
ehat2 = 0.3725;
ehat3 = 0.8543;
phi = [90:30:270]*pi/180;
for j=1:length(phi)
q1 = ehat1*sin(phi(j)/2); q2 = ehat2*sin(phi(j)/2); q3 = ehat3*sin(phi(j)/2); 
q4 = cos(phi(j)/2);
ICs = [q1, q2, q3, q4];

% Linear
mag = zeros(length(time),1);
quat = zeros(length(time),4);
quatn = zeros(length(time),4);
mag(1) = norm(ICs);
quat(1,:,j) = ICs;
quatn(1,:,j) = ICs/mag(1);

for nk = 1:2
   if nk==1 
      x0=quat(1,:,j)';
   else
      x0=quatn(1,:,j)';
   end
   for i=2:length(time)
      t = time(i-1);
      tt = t + dt2;
      dxdt = deriv_quat(t,x0);
      x0t = x0 + dt2*dxdt;
      dx0t = deriv_quat(tt,x0t);
      x0t = x0 + dt2*dx0t;
      dxmold = deriv_quat(tt,x0t);
      x0t = x0 + dt*dxmold;
      dxm = dx0t + dxmold;
      dx0t = deriv_quat(t + dt, x0t);
      x0 = x0 + dt6*(dxdt + dx0t + 2*dxm);
      if nk==1 
        quat(i,:,j) = x0';
        mag(i) = norm(x0);
      else
        quatn(i,:,j) = x0/norm(x0);
      end
   end
end


% discontinuous
mag = zeros(length(time),1);
quat1 = zeros(length(time),4);
quatn1 = zeros(length(time),4);
mag(1) = norm(ICs);
quat1(1,:,j) = ICs;
quatn1(1,:,j) = ICs/mag(1);

for nk = 1:2
   if nk==1 
      x0=quat1(1,:,j)';
   else
      x0=quatn1(1,:,j)';
   end
   for i=2:length(time)
      t = time(i-1);
      tt = t + dt2;
      dxdt = deriv_quat1(t,x0);
      x0t = x0 + dt2*dxdt;
      dx0t = deriv_quat1(tt,x0t);
      x0t = x0 + dt2*dx0t;
      dxmold = deriv_quat1(tt,x0t);
      x0t = x0 + dt*dxmold;
      dxm = dx0t + dxmold;
      dx0t = deriv_quat1(t + dt, x0t);
      x0 = x0 + dt6*(dxdt + dx0t + 2*dxm);
      if nk==1 
        quat1(i,:,j) = x0';
        mag(i) = norm(x0);
      else
        quatn1(i,:,j) = x0/norm(x0);
      end
   end
end


% nonlinear
mag = zeros(length(time),1);
quat2 = zeros(length(time),4);
quatn2 = zeros(length(time),4);
mag(1) = norm(ICs);
quat2(1,:,j) = ICs;
quatn2(1,:,j) = ICs/mag(1);

for nk = 1:2
   if nk==1 
      x0=quat2(1,:,j)';
   else
      x0=quatn2(1,:,j)';
   end
   for i=2:length(time)
      t = time(i-1);
      tt = t + dt2;
      dxdt = deriv_quat2(t,x0);
      x0t = x0 + dt2*dxdt;
      dx0t = deriv_quat2(tt,x0t);
      x0t = x0 + dt2*dx0t;
      dxmold = deriv_quat2(tt,x0t);
      x0t = x0 + dt*dxmold;
      dxm = dx0t + dxmold;
      dx0t = deriv_quat2(t + dt, x0t);
      x0 = x0 + dt6*(dxdt + dx0t + 2*dxm);
      if nk==1 
        quat2(i,:,j) = x0';
        mag(i) = norm(x0);
      else
        quatn2(i,:,j) = x0/norm(x0);
      end
   end
end

for i=1:length(time)
    PRAQ(i,j) = mod(2*atan2(norm(quatn(i,1:3,j),2),abs(quatn(i,4,j))) * 180/pi,180);
    PRAQ1(i,j) = mod(2*atan2(norm(quatn1(i,1:3,j),2),abs(quatn1(i,4,j))) * 180/pi,180);
    PRAQ2(i,j) = mod(2*atan2(norm(quatn2(i,1:3,j),2),abs(quatn2(i,4,j))) * 180/pi,180);
end
end

figure;
subplot(3,1,1)
hold on
for j=1:length(phi)
    plot(time, PRAQ(:,j))
end
grid on
ylim([0 180])
xlim([0 tf])
ylabel('Principle Axis [deg]')
title('Linear Quat Control (Range of IC)')
xlabel('Time [sec]')
legend('90','120','150','180','210','240','270')
subplot(3,1,2)
hold on
for j=1:length(phi)
    plot(time, PRAQ1(:,j))
end
grid on
ylim([0 180])
xlim([0 tf])
ylabel('Principle Axis [deg]')
title('Discontinuous Quat Control (Range of IC)')
xlabel('Time [sec]')
legend('90','120','150','180','210','240','270')
subplot(3,1,3)
hold on
for j=1:length(phi)
    plot(time, PRAQ2(:,j))
end
grid on
ylim([0 180])
xlim([0 tf])
ylabel('Principle Axis [deg]')
title('Nonlinear Quat Control (Range of IC)')
xlabel('Time [sec]')
legend('90','120','150','180','210','240','270')




%% MRP
k = 0.65;
% initial conditions
% Large Angle
 % e = [1, -2, 3]';
 % ehat = e/norm(e,2);
 % phi = 3;
% Small Angle 
e = [1, -2, 3]';
ehat = e/norm(e,2);
phi = 0.8;

IC = tan(phi/4)*ehat;
% Linear control
x0 = IC;
mrp(1,:) = IC';
dt2 = dt/2;
dt6 = dt/6;

for i=2:length(time)
    t = time(i-1);
    tt = t +dt2;
    dxdt = deriv_mrp1(t,x0);
    x0t = x0 + dt2*dxdt;
    dx0t = deriv_mrp1(tt,x0t);
    x0t = x0 + dt2*dx0t;
    dxmold = deriv_mrp1(tt,x0t);
    x0t = x0 + dt*dxmold;
    dxm = dx0t + dxmold;
    dx0t = deriv_mrp1(t+dt,x0t);
    x0 = x0 +dt6*(dxdt + dx0t + 2*dxm);

    mag2(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    if (mag2(i,:)>1)
        x0 = -x0/mag2(i,:);
        mag2(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    end
    mrp(i,:) = x0';
end




MRP1cont = -k * mrp;
MRP1_cost = trapz(t, sum(MRP1cont.^2, 2))

% Principle angle error
for j = 1:length(time)
PRA(j) = mod(4*atan(norm(mrp(j,:),2)) * 180/pi,180);
omega(j) = norm(MRP1cont(j,:));
end



figure;
subplot(1,3,1)
hold on
plot(time, mrp(:,1), 'r','LineWidth',1.5)
plot(time, mrp(:,2), 'b','LineWidth',1.5)
plot(time, mrp(:,3), 'g','LineWidth',1.5)
legend('\sigma_1','\sigma_2','\sigma_3','location','northeast')
title('Linear MRP feedback')
grid on
xlabel('time [sec]')
ylabel('MRP Components')
xlim([0 tf])
subplot(1,3,2)
hold on
plot(time, MRP1cont)
plot(time, omega, 'c','LineStyle','--','LineWidth',1.5)
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
grid on
xlabel('time [sec]')
ylabel('\omega [rad/s]')
xlim([0 tf])
title('Angular Velocity')
subplot(1,3,3)
plot(time, PRA, 'r', 'LineWidth',1.5)
grid on
title('Principle Angle Error')
xlabel('time [sec]')
ylabel('PRA [deg]')
xlim([0 tf])
ylim([0 180])

% non linear control

x0 = IC;
mrp1(1,:) = IC';
dt2 = dt/2;
dt6 = dt/6;

for i=2:length(time)
    t = time(i-1);
    tt = t +dt2;
    dxdt = deriv_mrp2(t,x0);
    x0t = x0 + dt2*dxdt;
    dx0t = deriv_mrp2(tt,x0t);
    x0t = x0 + dt2*dx0t;
    dxmold = deriv_mrp2(tt,x0t);
    x0t = x0 + dt*dxmold;
    dxm = dx0t + dxmold;
    dx0t = deriv_mrp2(t+dt,x0t);
    x0 = x0 +dt6*(dxdt + dx0t + 2*dxm);

    mag21(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    if (mag21(i,:)>1)
        x0 = -x0/mag21(i,:);
        mag21(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    end
    mrp1(i,:) = x0';
end

MRP2cont = -k * mrp1/ (1 + norm(mrp1,2).^2);
MRP2_cost = trapz(t, sum(MRP2cont.^2, 2))

% Principle angle error
for j = 1:length(time)
PRA(j) = mod(4*atan(norm(mrp1(j,:),2)) * 180/pi,180);
omega(j) = norm(MRP2cont(j,:));
end

figure;
subplot(1,3,1)
hold on
plot(time, mrp1(:,1), 'r','LineWidth',1.5)
plot(time, mrp1(:,2), 'b','LineWidth',1.5)
plot(time, mrp1(:,3), 'g','LineWidth',1.5)
legend('\sigma_1','\sigma_2','\sigma_3','location','northeast')
title('Nonlinear MRP feedback')
grid on
xlabel('time [sec]')
ylabel('MRP Components')
xlim([0 tf])
subplot(1,3,2)
hold on
plot(time, MRP2cont)
plot(time, omega, 'c','LineStyle','--','LineWidth',1.5)
legend('\omega_1','\omega_2','\omega_3','|\omega|', 'location','northeast')
grid on
xlabel('time [sec]')
ylabel('\omega [rad/s]')
xlim([0 tf])
title('Angular Velocity')
subplot(1,3,3)
plot(time, PRA, 'r', 'LineWidth',1.5)
grid on
title('Principle Angle Error')
xlabel('time [sec]')
ylabel('PRA [deg]')
xlim([0 tf])
ylim([0 180])


for i = 1:length(time)
    sig1(i) = norm(mrp(i,:));
    sig2(i) = norm(mrp1(i,:));
end
figure;
subplot(2,1,1)
plot(time, sig1, 'b')
title('Linear Control MRP magnitude')
grid on
xlabel('time [sec]')
ylabel('\sigma^2')
xlim([0 tf])
subplot(2,1,2)
plot(time, sig2, 'b')
grid on
title('Non-Linear Control MRP magnitude')
xlabel('time [sec]')
ylabel('\sigma^2')
xlim([0 tf])

% Testing Range of Phi
phi = [90:30:270]*pi/180;

for j=1:length(phi)
IC = tan(phi(j)/4)*ehat;

x0 = IC;
mrp3(1,:,j) = IC';
dt2 = dt/2;
dt6 = dt/6;

%Linear Control Law
for i=2:length(time)
    t = time(i-1);
    tt = t +dt2;
    dxdt = deriv_mrp1(t,x0);
    x0t = x0 + dt2*dxdt;
    dx0t = deriv_mrp1(tt,x0t);
    x0t = x0 + dt2*dx0t;
    dxmold = deriv_mrp1(tt,x0t);
    x0t = x0 + dt*dxmold;
    dxm = dx0t + dxmold;
    dx0t = deriv_mrp1(t+dt,x0t);
    x0 = x0 +dt6*(dxdt + dx0t + 2*dxm);

    mag2(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    if (mag2(i,:)>1)
        x0 = -x0/mag2(i,:);
        mag2(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    end
    mrp3(i,:,j) = x0';
end

%NonLinear Control Law
x0 = IC;
mrp4(1,:,j) = IC';
dt2 = dt/2;
dt6 = dt/6;

for i=2:length(time)
    t = time(i-1);
    tt = t +dt2;
    dxdt = deriv_mrp2(t,x0);
    x0t = x0 + dt2*dxdt;
    dx0t = deriv_mrp2(tt,x0t);
    x0t = x0 + dt2*dx0t;
    dxmold = deriv_mrp2(tt,x0t);
    x0t = x0 + dt*dxmold;
    dxm = dx0t + dxmold;
    dx0t = deriv_mrp2(t+dt,x0t);
    x0 = x0 +dt6*(dxdt + dx0t + 2*dxm);

    mag21(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    if (mag21(i,:)>1)
        x0 = -x0/mag21(i,:);
        mag21(i,:)=x0(1)^2+x0(2)^2+x0(3)^2;
    end
    mrp4(i,:,j) = x0';
end

for i = 1:length(time)
PRAL(i,j) = mod(4*atan(norm(mrp3(i,:,j),2)) * 180/pi,180);
PRANL(i,j) = mod(4*atan(norm(mrp4(i,:,j),2)) * 180/pi,180);
end
end

figure;
subplot(2,1,1)
hold on
for j=1:length(phi)
    plot(time, PRAL(:,j))
end
grid on
ylim([0 180])
xlim([0 tf])
ylabel('Principle Axis [deg]')
title('Linear MRP Control (Range of IC)')
xlabel('Time [sec]')
legend('90','120','150','180','210','240','270')
subplot(2,1,2)
hold on
for j=1:length(phi)
    plot(time, PRANL(:,j))
end
grid on
ylim([0 180])
xlim([0 tf])
ylabel('Principle Axis [deg]')
title('Nonlinear MRP Control (Range of IC)')
xlabel('Time [sec]')
legend('90','120','150','180','210','240','270')



end

%% subfunctions used within code
function dX = PRV(t, X)
k = .45;

gdot = -k*X;

dX = [gdot];
end
function S = skew(v)
S = [  0    -v(3)   v(2);
       v(3)   0    -v(1);
      -v(2)  v(1)    0 ];
end



function dquat = deriv_quat(t, quat)
% Angular velocity (convert to rads)
k = .45;


q1 = quat(1);
q2 = quat(2);
q3 = quat(3);
q4 = quat(4);
ep = [q1; q2; q3];
omega = -k*ep;
dq4 = -1/2*omega'*ep;
dep = -1/2*skew(omega)*ep+1/2*omega*q4;


% Return the quaternion rates in a vector
dquat = [dep; dq4];

end

function dquat = deriv_quat1(t, quat)
% Angular velocity (convert to rads)
k = .45;


q1 = quat(1);
q2 = quat(2);
q3 = quat(3);
q4 = quat(4);
ep = [q1; q2; q3];
if q4 == 0
    omega = -k*ep;
else
omega = -k*sign(q4)*ep;
end
dq4 = -1/2*omega'*ep;
dep = -1/2*skew(omega)*ep+1/2*omega*q4;


% Return the quaternion rates in a vector
dquat = [dep; dq4];

end

function dquat = deriv_quat2(t, quat)
% Angular velocity (convert to rads)
k = .45;


q1 = quat(1);
q2 = quat(2);
q3 = quat(3);
q4 = quat(4);
ep = [q1; q2; q3];
omega = -k*q4*ep;
dq4 = -1/2*omega'*ep;
dep = -1/2*skew(omega)*ep+1/2*omega*q4;


% Return the quaternion rates in a vector
dquat = [dep; dq4];

end


function dmrp = deriv_mrp1(t, mrp)
k = 0.65;
omega = -k * mrp;
sg1 = mrp(1);
sg2 = mrp(2);
sg3 = mrp(3);
B(1,1) = 1+sg1^2-sg2^2-sg3^2;
B(1,2) = 2*(sg1*sg2-sg3);
B(1,3)= 2*(sg1*sg3+sg2);
B(2,1) = 2*(sg2*sg1+sg3);
B(2,2) = 1-sg1^2+sg2^2-sg3^2;
B(2,3) = 2*(sg2*sg3-sg1);
B(3,1) = 2*(sg3*sg1-sg2);
B(3,2) = 2*(sg3*sg2+sg1);
B(3,3) = 1-sg1^2-sg2^2+sg3^2;

dmrp = 0.25*B*omega;
end

function dmrp = deriv_mrp2(t, mrp)
k = 0.65;
omega = -k * mrp/ (1 + norm(mrp,2)^2);
sg1 = mrp(1);
sg2 = mrp(2);
sg3 = mrp(3);
B(1,1) = 1+sg1^2-sg2^2-sg3^2;
B(1,2) = 2*(sg1*sg2-sg3);
B(1,3)= 2*(sg1*sg3+sg2);
B(2,1) = 2*(sg2*sg1+sg3);
B(2,2) = 1-sg1^2+sg2^2-sg3^2;
B(2,3) = 2*(sg2*sg3-sg1);
B(3,1) = 2*(sg3*sg1-sg2);
B(3,2) = 2*(sg3*sg2+sg1);
B(3,3) = 1-sg1^2-sg2^2+sg3^2;

dmrp = 0.25*B*omega;
end